const isOdd = (key) => {
  return key & 1 ? true : false;
};

export default isOdd;

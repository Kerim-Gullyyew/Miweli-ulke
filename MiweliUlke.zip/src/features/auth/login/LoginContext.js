export const LoginContext = {
    login: "Login",
    usernameplaceholder: "Username",
    password: "password",
    forgotpassword: "Forgot Password?",
    loginbutton: "Login",
    passwordplaceholder: "Password",
    usernamehtmlFor: "username",
    passwordhtmlFor: "password"
};
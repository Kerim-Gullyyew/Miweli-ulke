export const ProductContext = {
    code: "Kody",
    title: "Ady",
    price: "Bahasy",
    qrcode: "Qr Kod",
    description: "Düşündiriş",
    status: "Statusy",
    unit: "Ölçeg birlik",
    image: "Suraty",
    arrived_at: "Gelen wagty",
    attribute: "Goşmaça maglumat",
    action: "Action",
};

export const ProductFilterContext = {
    title: "Ady",
    code: "Kod",
    minprice: "Iň kiçi baha",
    maxprice: "Iň uly baha",
}
export const ProductStatusContext ={
    active: "Aktiw",
    inactive: "Inaktiw",
}

export const ProductDetailContext = {
    name: "Ady",
    value: "Bahasy",
    action: "Action",
}

export const ProductAttributeContext = {
    title: "Ady",
}
export const ProductUnitNewContext = {
    title: "Ady",
}

export const ProductAttributeNewContext = {
    title: "Täze goşmaça maglumat girizmek",
    name: "Ady",
    value: "Bahasy",

}
export const MoveContext = {
    out_cell: "Öýjükden",
    in_cell: "Öýjüge",
    username: "Ady",
    created_at: "Döredilen wagty",
    updated_at: "Üýtgedilen wagty",
    action: "Action",
};
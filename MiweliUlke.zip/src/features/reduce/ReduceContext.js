export const ReduceContext = {
    image: "Surat",
    price: "Baha",
    amount: "Mukdar",
    user: "Dörediji",
    reason: "Sebap",
    pallet: "Palet",
    attr: "Goşmaça maglumat",
    description: "Düşündiriş",
    created_at: "Döredilen wagty",
    updated_at: "Üýtgedilen wagty",
    action: "Action",
};
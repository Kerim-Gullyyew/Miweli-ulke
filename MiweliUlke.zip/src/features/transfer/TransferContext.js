export const TransferContext ={
    title: "Ady",
    description: "Düşündiriş",
    created_at: "Döredilen wagty",
    action: "Action",
    email: "email",
    creater: "Döreden adam",
    updated_at: "Üýtgedilen wagty",
}

export const TransferType = {
    income: "Поступление",
    outcome: "Отправление",
}

export const TransferFilterContext = {
    startdate: "Başlangyç wagty",
    enddate: "Soňky wagty",
}

export const TransferAttributeNewContext = {
    title: "Partiýa Goşmaça maglumat goşmak",
    name: "Ady",
    value: "Bahasy",
}

export const Attributes = {
    attributes: "Goşmaça maglumatlar"
}

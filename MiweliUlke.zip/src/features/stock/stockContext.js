export const cellContext = {
    code: "Kody",
    pallettitle: "Palet Ady",
    palletcode: "Palet Kody",
    product: "Haryt",
    empty: "Boş",
    image: "Surat",
};
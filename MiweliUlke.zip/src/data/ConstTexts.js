export const projectName = "Miweli ülke";
export const backendUrl = "http://119.235.114.34";
// export const backendUrl = "http://10.1.1.201";
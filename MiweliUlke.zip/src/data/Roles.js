export const Employee = "Employee";
export const Manager = "Manager";
export const Stock = "Stock";
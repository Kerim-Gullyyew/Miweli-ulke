export const uiContext = {
    batch: "Partiýa",
    stock: "Ammar",
    product: "Harytlar",
    account: "Akaunt",
    transaction: "Çykyş",
    reduce: "Braklary aýyrmak",
    move: "Ýerini Üýtgetmek",
    logout: "Çykmak",
    setting: "Üýtgetmek",
};
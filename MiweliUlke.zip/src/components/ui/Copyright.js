import React from 'react'

const Copyright = () => {
  return (
    <div>Copyright</div>
  )
}

export default Copyright
export const paginationContext = {
    prev: "Prev",
    next: "Next",
}
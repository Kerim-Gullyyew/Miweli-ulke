// export const uiStyle = {
//     icon: "flex items-center flex-col space-y-3 cursor-pointer",
//     iconText: "text-black",
//     iconTextMobile: "text-lg font-poppins font-bold pl-5",
//     iconTextSidebar: "text-base font-poppins font-bold pl-3",
//     iconSize: 30,
//     iconListMobile: "flex items-center py-2 cursor-pointer",
//     iconSidebar: "hover:bg-gray-500 hover:bg-opacity-10 hover:text-blue-600 flex items-center py-1.5  rounded space-x-2 cursor-pointer",
// };
import React from "react";

const T_data = ({data}) => {
  return <td className="border whitespace-nowrap px-6 py-2 font-medium">{data}</td>;
};

export default T_data;
